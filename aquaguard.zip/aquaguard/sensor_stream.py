"""
sensor_stream.py
------------------
Simulates a live IoT sensor feed for a river monitoring station.

In production this would be a socket/MQTT subscriber receiving readings from
physical probes (pH, turbidity, dissolved oxygen, conductivity) every few
minutes. Here it's a Python generator that yields one reading per "tick" --
the rest of the pipeline (anomaly.py, classifier.py, ...) consumes it exactly
the way it would consume a real live feed, so swapping this module for an
MQTT client later doesn't change anything downstream.

Baseline values are typical for a healthy freshwater river. Around tick 15
the stream injects a pollution event so the pipeline has something to catch.
"""

import random
import time

BASELINE = {"ph": 7.2, "turbidity": 8.0, "dissolved_oxygen": 7.5, "conductivity": 420}

# Sensor "fingerprints" for different pollution sources -- each nudges the
# baseline in a distinct, physically realistic direction.
EVENT_PROFILES = {
    "industrial_effluent": {"ph": -1.1, "turbidity": +5, "dissolved_oxygen": -3.5, "conductivity": +760},
    "agricultural_runoff": {"ph": -0.3, "turbidity": +35, "dissolved_oxygen": -1.0, "conductivity": +90},
    "sewage_leak": {"ph": -0.5, "turbidity": +20, "dissolved_oxygen": -4.5, "conductivity": +180},
}


def stream(ticks: int = 30, event_at: int = 15, event_type: str = "industrial_effluent", seed: int = 7):
    """
    Yields (tick, {sensor: value, ...}) pairs, one per call, simulating a
    live feed. Small random noise is always present; from `event_at` onward
    the readings shift according to `event_type`'s profile and keep drifting
    (a real leak doesn't self-correct), demonstrating a live-detectable event.
    """
    rng = random.Random(seed)
    reading = dict(BASELINE)

    for t in range(ticks):
        noisy = {k: v + rng.gauss(0, 0.02 * abs(v) + 0.05) for k, v in reading.items()}

        if t >= event_at:
            profile = EVENT_PROFILES[event_type]
            progress = min(1.0, (t - event_at + 1) / 5.0)  # ramps in over ~5 ticks
            noisy = {k: v + profile.get(k, 0) * progress for k, v in noisy.items()}

        yield t, {k: round(v, 2) for k, v in noisy.items()}
