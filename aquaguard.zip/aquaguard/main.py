"""
main.py
--------
Runs the AquaGuard real-time pipeline against a simulated 30-tick sensor
stream (each tick standing in for one live reading, e.g. every 5 minutes
in a real deployment). A pollution event is injected partway through so
the anomaly detector, source classifier, RAG retrieval, and alert agent
can all be seen firing in sequence -- printed as a live monitoring log.

Usage:
    python main.py                              # default: industrial effluent event
    python main.py agricultural_runoff           # try a different pollution fingerprint
    python main.py sewage_leak
"""

import sys
import time
from sensor_stream import stream
from pipeline import AquaGuardPipeline


def main():
    event_type = sys.argv[1] if len(sys.argv) > 1 else "industrial_effluent"
    valid = {"industrial_effluent", "agricultural_runoff", "sewage_leak"}
    if event_type not in valid:
        print(f"Unknown event type '{event_type}'. Choose from: {sorted(valid)}")
        return

    print(f"AquaGuard live monitor -- station RVR-SRKKLM-04")
    print(f"Simulating a '{event_type}' pollution event starting at tick 15\n")

    pipeline = AquaGuardPipeline()

    for tick, reading in stream(ticks=30, event_at=15, event_type=event_type):
        result = pipeline.process_tick(tick, reading)

        status = "ANOMALY" if result["anomaly"] else "normal "
        print(f"[t={tick:02d}] {status} | {result['reading']}")

        if result["anomaly"] and "classification" in result:
            print(f"          -> {result['attribution_text']}")
            if result.get("retrieved"):
                print(f"          -> Alert {result['alert_id']} -> {result['retrieved']['authority']}")

    # simulate checking escalations 45 minutes later, with nothing acknowledged
    print("\n--- 45 minutes later, checking for unacknowledged alerts ---")
    pipeline.agent.check_escalations(now=time.time() + 45 * 60)

    print("\nFULL AGENT ACTION LOG:")
    for line in pipeline.agent.action_log:
        print(" -", line)

    print("\nPRIVACY-SAFE EVENT LOG (station + label + confidence only):")
    for entry in pipeline.event_log:
        print(" -", entry)


if __name__ == "__main__":
    main()
