# AquaGuard — Real-Time AI Water Quality & Pollution Source-Tracing — Project Code

Working prototype for the **1M1B AI for Sustainability Virtual Internship**
(in collaboration with IBM SkillsBuild & AICTE).

- **Title:** AquaGuard — Real-Time AI for Water Quality Monitoring & Pollution Source-Tracing
- **Student:** Dabbeeru Priyanka, Aditya Institute of Technology and Management (AITAM), Tekkali
- **Primary SDG:** SDG 6 — Clean Water and Sanitation · **Secondary SDG:** SDG 15 — Life on Land
- **Problem statement:** How might we use AI to detect river pollution in real time so that
  contamination sources can be traced and stopped before lasting harm occurs?

This is a **real-time, streaming** prototype — unlike a single-shot image classifier, it
continuously ingests one sensor reading per tick, maintains a live rolling baseline, and
reacts the moment a reading drifts from normal. That continuous, closed-loop behaviour is
what makes this project distinct from a one-off classification demo.

## How to run

```bash
cd aquaguard
python main.py                      # simulates an industrial effluent event
python main.py agricultural_runoff  # try a different pollution fingerprint
python main.py sewage_leak
```

No external dependencies — pure Python standard library. Each run simulates 30 "ticks"
of a live sensor feed (e.g. one reading every 5 minutes in reality), injects a pollution
event partway through, and prints a live monitoring log ending in the full agent action
log and a privacy-safe event log.

## Architecture — file by file

| File | AI Solution Overview component | What it does |
|---|---|---|
| `sensor_stream.py` | (live data source) | Simulates a streaming IoT sensor feed (pH, turbidity, dissolved oxygen, conductivity), with an injectable pollution event |
| `anomaly.py` | **Real-Time Anomaly Detection** | Rolling-baseline z-score detector; flags a reading the moment it deviates sharply |
| `source_classifier.py` | **Source Classification** | Matches the anomaly's sensor-deviation *shape* (cosine similarity) against known pollution fingerprints |
| `knowledge_base.py` | **RAG-Based Response Guidance** | Retrieval corpus: treatment/response protocol + responsible authority per source type |
| `responsible_ai.py` | **Responsible AI Considerations** | Confidence gating, non-accusatory phrasing, privacy-safe logging |
| `alert_agent.py` | **Agentic Alert Routing** | Opens one alert per incident, routes to the right authority, escalates if unacknowledged — and won't spam or flip-flop labels mid-incident |
| `pipeline.py` | (orchestrator) | Wires Sense → Detect → Classify → Retrieve → Alert & Escalate together, one tick at a time |
| `main.py` | — | Demo entry point |

## Note on the classifier

No historical labeled pollution-event dataset is available in this environment, so
`source_classifier.py` uses a transparent, fully-working **cosine-similarity fingerprint
matcher**: each pollution type has a known sensor "signature" (e.g. industrial effluent
spikes conductivity far more than turbidity; sewage crashes dissolved oxygen hardest;
runoff moves turbidity most) — the same physical knowledge a trained classifier would
have to learn from data. In production, replace this with a model trained on logged
historical incidents; the output format (`{"label", "confidence", "all_scores"}`) stays
the same, so nothing downstream needs to change.

## Responsible AI guardrails (enforced in code, not just described)

- **Transparency:** every alert states the exact confidence score and the sensor readings that triggered it.
- **Ethics:** low-confidence anomalies (`responsible_ai.check_confidence`) are logged for manual review but never given an automated source label. Confident predictions are phrased as a "likely zone to investigate, pending human confirmation" (`phrase_attribution`) — never a confirmed accusation against a named party.
- **Fairness:** the baseline is per-station and self-calibrating from that station's own recent history, rather than one fixed global threshold applied to every river segment regardless of natural local variation.
- **Privacy:** the persisted event log stores only station ID + predicted label + confidence (`anonymize_for_log`) — never any personal or vehicle data.
- **Anti-flip-flop / anti-spam:** the alert agent keeps one open incident per station rather than raising a new alert (or silently relabeling an existing one) every time a noisy reading's classification wobbles — a deliberate agentic design choice, not just a filter.

## Example output

```
AquaGuard live monitor -- station RVR-SRKKLM-04
Simulating a 'industrial_effluent' pollution event starting at tick 15

[t=15] ANOMALY | {'ph': 7.1, 'turbidity': 8.87, 'dissolved_oxygen': 6.71, 'conductivity': 561.31}
          -> a likely industrial effluent event -- pending human confirmation before any formal action
          -> Alert RVR-SRKKLM-04-industrial_effluent-1 -> Pollution Control Board -- Industrial Compliance Unit

...

--- 45 minutes later, checking for unacknowledged alerts ---

FULL AGENT ACTION LOG:
 - ALERT RAISED [RVR-SRKKLM-04-industrial_effluent-1] -> Pollution Control Board -- Industrial Compliance Unit | ... (confidence 100%)
 - ALERT REINFORCED [RVR-SRKKLM-04-industrial_effluent-1] -- another matching anomalous reading
 - ESCALATED [RVR-SRKKLM-04-industrial_effluent-1] -> no response within 30 min, notifying District Environmental Officer
```
