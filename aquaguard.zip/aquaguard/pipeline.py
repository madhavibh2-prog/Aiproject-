"""
pipeline.py
------------
Wires the five real-time stages together:

    Sense -> Detect -> Classify -> Retrieve -> Alert & Escalate

One call to `process_tick()` handles exactly one incoming sensor reading,
the way a real streaming consumer would process one message off a queue.
"""

from anomaly import RollingBaseline, is_anomalous, anomaly_summary
from source_classifier import classify_source
from knowledge_base import retrieve
from responsible_ai import check_confidence, phrase_attribution, anonymize_for_log
from alert_agent import AlertAgent

STATION_ID = "RVR-SRKKLM-04"


class AquaGuardPipeline:
    def __init__(self):
        self.baseline = RollingBaseline()
        self.agent = AlertAgent()
        self.event_log: list[dict] = []

    def process_tick(self, tick: int, reading: dict) -> dict:
        # 1. Sense -- `reading` is the incoming sensor message
        # 2. Detect
        z_scores = self.baseline.update_and_score(reading)
        anomaly_flag = is_anomalous(z_scores)

        result = {"tick": tick, "reading": reading, "z_scores": z_scores, "anomaly": anomaly_flag}

        if not anomaly_flag:
            return result

        # 3. Classify
        classification = classify_source(z_scores)
        confident = check_confidence(classification["confidence"])
        attribution_text = phrase_attribution(classification["label"], confident)
        result["classification"] = classification
        result["attribution_text"] = attribution_text

        # 4. Retrieve (only if confident enough to name a likely source)
        retrieved = retrieve(classification["label"]) if confident else None
        result["retrieved"] = retrieved

        # 5. Alert & Escalate
        if retrieved:
            alert_id = self.agent.raise_alert(STATION_ID, retrieved, classification["confidence"], attribution_text)
            result["alert_id"] = alert_id
        else:
            self.agent.action_log.append(
                f"LOW-CONFIDENCE ANOMALY at tick {tick} on sensors {anomaly_summary(z_scores)} "
                f"-- logged for manual review, no automated attribution made"
            )

        log_entry = anonymize_for_log(STATION_ID, classification["label"], classification["confidence"])
        self.event_log.append(log_entry)

        return result
