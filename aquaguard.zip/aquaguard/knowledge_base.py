"""
knowledge_base.py + retrieval
--------------------------------
AI Component 3: RAG-based response guidance.

KNOWLEDGE_BASE stands in for a vector store of environmental-compliance
documents (Pollution Control Board protocols, CPCB effluent standards).
retrieve() fetches the matching entry for a predicted source type -- a real
system would embed and similarity-search document chunks; the output shape
is identical either way.
"""

KNOWLEDGE_BASE = {
    "industrial_effluent": {
        "summary": "Sharp conductivity rise with falling dissolved oxygen and pH drop, consistent with untreated industrial discharge.",
        "protocol": (
            "Notify the Pollution Control Board's industrial compliance unit immediately. "
            "Cross-check discharge logs of registered units within 2 km upstream of the sensor. "
            "Restrict water use for drinking/irrigation downstream until cleared."
        ),
        "authority": "Pollution Control Board -- Industrial Compliance Unit",
        "source": "CPCB Effluent Discharge Standards, Schedule VI",
    },
    "agricultural_runoff": {
        "summary": "Turbidity spike with modest conductivity change, consistent with fertilizer/pesticide runoff after rainfall.",
        "protocol": (
            "Notify the local agricultural extension office and municipal water utility. "
            "Recommend buffer-zone and runoff-control advisory to farms in the watershed. "
            "Increase monitoring frequency for the next 48 hours."
        ),
        "authority": "Municipal Water Utility + Agricultural Extension Office",
        "source": "State Watershed Management Guidelines",
    },
    "sewage_leak": {
        "summary": "Turbidity rise with sharply falling dissolved oxygen, consistent with untreated sewage intrusion.",
        "protocol": (
            "Notify the municipal sanitation department for immediate pipeline inspection. "
            "Issue a public health advisory for downstream water contact within 5 km. "
            "Flag for follow-up water-borne-illness surveillance."
        ),
        "authority": "Municipal Sanitation Department + Public Health Office",
        "source": "Municipal Water Safety Protocol, Section 4",
    },
}


def retrieve(label: str) -> dict | None:
    entry = KNOWLEDGE_BASE.get(label)
    if entry is None:
        return None
    return {"label": label, **entry}
