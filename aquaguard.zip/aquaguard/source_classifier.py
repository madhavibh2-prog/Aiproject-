"""
source_classifier.py
----------------------
AI Component 2: Source Classification.

Once anomaly.py flags a reading, this module compares the FULL PATTERN of
deviation (direction AND relative magnitude across all four sensors) against
each known pollution "fingerprint" using cosine similarity -- the standard
way to compare a live reading's shape against reference patterns when the
values aren't on the same scale. Fingerprints are the same physically
motivated sensor shifts documented in sensor_stream.EVENT_PROFILES (e.g.
industrial effluent spikes conductivity far more than turbidity; sewage
crashes dissolved oxygen hardest; runoff moves turbidity most).

This is a rule-based nearest-fingerprint matcher -- a fully transparent
stand-in for a trained classifier (e.g. a small gradient-boosted model fit
on labeled historical events). Its output shape ({label, confidence}) is
what a trained model would return, so it's a drop-in swap later.
"""

import math
from sensor_stream import EVENT_PROFILES, BASELINE

SENSOR_KEYS = ["ph", "turbidity", "dissolved_oxygen", "conductivity"]


def _std_floor(key: str) -> float:
    """Must mirror the floor used in anomaly.RollingBaseline so fingerprints
    live in the same standardized (z-score) units as the live readings."""
    return 0.03 * abs(BASELINE[key]) + 0.1


# Pre-standardize each fingerprint into the same z-score units the live
# anomaly detector produces, so comparing shapes is a fair apples-to-apples
# match rather than raw-unit deltas (where e.g. conductivity's large
# absolute swing would dominate purely from scale, not from being the most
# *distinctive* signal).
FINGERPRINT_VECTORS = {
    label: [profile.get(k, 0.0) / _std_floor(k) for k in SENSOR_KEYS]
    for label, profile in EVENT_PROFILES.items()
}


def _vector(d: dict) -> list:
    return [d.get(k, 0.0) for k in SENSOR_KEYS]


def _cosine_similarity(a: list, b: list) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a)) or 1e-6
    norm_b = math.sqrt(sum(y * y for y in b)) or 1e-6
    return dot / (norm_a * norm_b)


def classify_source(z_scores: dict) -> dict:
    z_vec = _vector(z_scores)
    all_scores = {}
    best_label, best_score = None, -1.0

    for label, fingerprint_vec in FINGERPRINT_VECTORS.items():
        similarity = _cosine_similarity(z_vec, fingerprint_vec)
        confidence = round(max(similarity, 0.0), 2)
        all_scores[label] = confidence
        if confidence > best_score:
            best_label, best_score = label, confidence

    return {"label": best_label, "confidence": best_score, "all_scores": all_scores}
