"""
anomaly.py
-----------
AI Component 1: Real-Time Anomaly Detection.

Maintains a rolling baseline (mean + standard deviation) per sensor
parameter and flags a reading as anomalous when it deviates more than
`Z_THRESHOLD` standard deviations from that rolling baseline -- a standard,
lightweight streaming-statistics approach used for real-time sensor
monitoring before reaching for a heavier learned model. It updates itself
tick by tick, exactly like a production streaming detector would.
"""

from collections import deque

WINDOW_SIZE = 10
Z_THRESHOLD = 3.0


class RollingBaseline:
    def __init__(self, window_size: int = WINDOW_SIZE, min_window: int = 6):
        self.window_size = window_size
        self.min_window = min_window
        self.history: dict[str, deque] = {}

    def _window(self, key: str) -> deque:
        if key not in self.history:
            self.history[key] = deque(maxlen=self.window_size)
        return self.history[key]

    def update_and_score(self, reading: dict) -> dict:
        """
        For each sensor value: compute a z-score against the rolling window
        BEFORE adding the new point (so the anomalous point doesn't smear
        its own baseline), then push it into the window.

        A floor on the standard deviation (proportional to the mean) keeps
        an unusually "quiet" early window from turning ordinary sensor
        noise into a false-positive extreme z-score.
        """
        scores = {}
        for key, value in reading.items():
            window = self._window(key)
            if len(window) >= self.min_window:
                mean = sum(window) / len(window)
                variance = sum((x - mean) ** 2 for x in window) / len(window)
                std = variance ** 0.5
                std_floor = 0.03 * abs(mean) + 0.1
                std = max(std, std_floor)
                scores[key] = round((value - mean) / std, 2)
            else:
                scores[key] = 0.0
            window.append(value)
        return scores


def is_anomalous(scores: dict) -> bool:
    return any(abs(z) >= Z_THRESHOLD for z in scores.values())


def anomaly_summary(scores: dict) -> list[str]:
    return [k for k, z in scores.items() if abs(z) >= Z_THRESHOLD]
