"""
alert_agent.py
----------------
AI Component 4: Agentic Alert Routing.

Decides WHO to notify and manages escalation over time -- the piece that
makes this an agent rather than a single model call. A real deployment
would send actual emails/SMS/webhook calls here; this module simulates
that by recording each action so the pipeline's decisions are inspectable.
"""

import time

ESCALATION_WINDOW_SECONDS = 30 * 60  # 30 minutes, matches the slide deck


class AlertAgent:
    def __init__(self):
        self.open_alerts: dict[str, dict] = {}
        self.action_log: list[str] = []

    def raise_alert(self, station_id: str, retrieved: dict, confidence: float, attribution_text: str):
        # Agentic behavior: an incident stays open under whichever source
        # label it was first raised with. Don't spam a new alert every tick,
        # and don't flip-flop the label if a later reading's classification
        # wobbles -- log the alternate read for a human to weigh instead.
        for alert_id, alert in self.open_alerts.items():
            if alert["station_id"] == station_id and not alert["acknowledged"]:
                if alert["label"] == retrieved["label"]:
                    self.action_log.append(f"ALERT REINFORCED [{alert_id}] -- another matching anomalous reading")
                else:
                    self.action_log.append(
                        f"ALERT NOTE [{alert_id}] -- this reading looks more like "
                        f"'{retrieved['label']}' ({confidence:.0%}); kept under original "
                        f"label pending human review, not auto-reclassified"
                    )
                return alert_id

        alert_id = f"{station_id}-{retrieved['label']}-{len(self.open_alerts) + 1}"
        self.open_alerts[alert_id] = {
            "station_id": station_id,
            "label": retrieved["label"],
            "authority": retrieved["authority"],
            "raised_at": time.time(),
            "acknowledged": False,
        }
        self.action_log.append(
            f"ALERT RAISED [{alert_id}] -> {retrieved['authority']} | {attribution_text} "
            f"(confidence {confidence:.0%}) | protocol: {retrieved['protocol']}"
        )
        return alert_id

    def acknowledge(self, alert_id: str):
        if alert_id in self.open_alerts:
            self.open_alerts[alert_id]["acknowledged"] = True
            self.action_log.append(f"ALERT ACKNOWLEDGED [{alert_id}]")

    def check_escalations(self, now: float | None = None):
        """Call periodically; escalates any alert open past the time window."""
        now = now if now is not None else time.time()
        for alert_id, alert in self.open_alerts.items():
            if not alert["acknowledged"] and (now - alert["raised_at"]) > ESCALATION_WINDOW_SECONDS:
                self.action_log.append(
                    f"ESCALATED [{alert_id}] -> no response from {alert['authority']} within "
                    f"{ESCALATION_WINDOW_SECONDS // 60} min, notifying District Environmental Officer"
                )
