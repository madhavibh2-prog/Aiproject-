"""
responsible_ai.py
-------------------
Guardrails referenced on the "Responsible AI Considerations" slide,
enforced in code rather than only described.
"""

CONFIDENCE_THRESHOLD = 0.5  # below this, the source label is withheld


def check_confidence(confidence: float) -> bool:
    """Transparency: never assert a specific source without reasonable evidence."""
    return confidence >= CONFIDENCE_THRESHOLD


def phrase_attribution(label: str, confidence: bool) -> str:
    """
    Ethics: the system always frames a source as a *likely zone to
    investigate*, never a confirmed accusation against a named party --
    that determination stays a human decision.
    """
    if not confidence:
        return "an unidentified contamination event (confidence too low to suggest a likely source)"
    readable = label.replace("_", " ")
    return f"a likely {readable} event -- pending human confirmation before any formal action"


def anonymize_for_log(station_id: str, label: str, confidence: float) -> dict:
    """Privacy: logs keep only the monitoring station ID, not any personal or vehicle data."""
    return {"station_id": station_id, "predicted_label": label, "confidence": confidence}
